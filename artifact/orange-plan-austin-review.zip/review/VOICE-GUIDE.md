# Austin voice guide — extracted from 4 real video scripts

> ## ⛔ Read `AUSTIN-AUTHORITY.md` before editing any lesson.
>
> Austin's dictated planning recommendation is the authority. You may fix math
> and facts (A), flag contradictions (B), and you may **not** rewrite a planning
> judgment (C) without his explicit direction. Open items live in
> `AUTHORITY-FLAGS.md`.

Calibration sources: "401K vs Bitcoin", "Bitcoin Is My Path To Early Retirement",
"Bitcoin Beginner's Guide", "How I Went From Nothing To Early Retirement".
Every script conversion is checked against this, not against "good writing."

## THE calibration master

`scripts/03-2_size-the-reserve-to-your-life.md` is Austin's own dictation of a
full lesson (2026-08-04). Every conversion matches THAT, not this guide's
abstractions. When guide and dictation disagree, the dictation wins.

## Dictation-derived rules (diffed against the same content written by AI)

- **Opener:** "In today's lesson, we're going to cover [thing]." Then optionally
  "Let me start by showing you why this matters."
- **"Going to" everywhere.** Austin scaffolds in future tense: "you're going to
  take," "this is going to push it up," "they're going to be starting at."
  AI-me wrote present tense; Austin doesn't.
- **"I think" hedges on every judgment.** "I think this is a good starting
  place." "I don't think there's a wrong answer here." Opinions are marked as
  opinions, never delivered as facts.
- **Unpack, don't compress.** Austin's version of any idea is LONGER than the
  written one: "they're now stuck in a situation where they're selling Bitcoin
  at a 77% loss just to cover all of their bills and their mortgage." Never
  tighten his kind of sentence for elegance — the restating and elaboration IS
  the teaching style.
- **Explicit causality.** Nearly every claim carries its "because": "...is also
  going to push it up, because you're just at a higher risk if you were to lose
  that source of income."
- **Transitions:** "On the flip side of this," "Let's walk through an example,"
  "Let's say that we have a couple," "Now, ..."
- **Homework is a numbered list, read out.** Enumerations are fine to speak.
- **The teach lesson refers to the app work as "the walkthrough below this
  video"** — teach and walkthrough are separate videos on the same lesson page.

## How Austin actually talks

- **Sentences chain with connectives.** "So..." starts the move, "And..." extends
  it, "Then..." sequences it, "But..." turns it, "Now..." shifts topic. Long
  conversational run-ons joined by "and"/"so" are normal and correct.
- **Judgment calls get grounded in real experience — mechanics don't.** When a
  claim could sound like advice or opinion (debt tolerance, holding through
  drawdowns, borrow-vs-sell), Austin backs it with something that actually
  happened: "I watched my net worth drop 75% in 2022." Plain mechanics
  (formulas, tax rules, app steps) are taught directly, no anecdote — forcing
  one in is its own kind of slop. HARD RULE: never invent experience. The only
  permitted "I" stories are Austin's documented ones: the 2022 -75% drawdown,
  cashing out the 401(k) in ~2020, 5% down on the house with the difference
  into Bitcoin, switching to CrowdHealth (~$1,000/mo saved), the thrift-store
  resale business, the MicroStrategy options loss, the $1,200 stimulus-check
  mountain bike. A lesson with no applicable true story gets no story.
- **Walks the viewer by the hand.** "So let me show you what I did." "Here's how
  to calculate yours." "You'll click receive, copy the address, then go back to
  River." Second person, imperative, concrete.
- **Problem → solution rhythm.** "The problem was that... So what I did was..."
  "The risk was... The solution is..." "This is important because..."
- **Numbers in digits, walked step by step.** "$206,000 times 12.5 equals roughly
  $2.58 million." "Take 0.2 and multiply it by itself." Never spelled out, never
  dropped as a punchline — always walked.
- **Hedged, non-advisory close on decisions.** "I'm not saying you should do
  this." "Run the numbers and see for yourself." "I'll let you be the judge."
  "Verify this for your situation."
- **Enumerations announced then delivered.** "So to find more dollars you have 3
  options." Then the three, plainly.
- **Occasional rhetorical question, immediately answered.** "The problem? Social
  Security's trust fund is projected to run out."

## What Austin does NOT do (the AI-slop tells — reject on sight)

- Aphorisms and punchlines ("peace of mind is a real return," "that's the storm
  the reserve is built to outlast"). At most ONE simple payoff line per video,
  not per paragraph.
- Em-dash parallelism and triads ("the tests, the splits, the math").
- Clever reversals and chiasmus ("buys insurance for a lifestyle you'd have cut").
- Fragments for drama. ("Months of paperwork. Done while grieving.")
- Spelled-out numbers ("seventy-seven percent").
- **"X doesn't go away, it just ___" / "it isn't A, it's B" / "that's not A, that's B."**
  The clever reversal. Reads as insight, contains none. If a sentence's job is to
  land rather than to inform, cut it and put the missing FACT there instead.
  (Caught 2026-08-04: "The bill doesn't go away, it just changes whose name is on
  it" replaced with the 10-year rule and why heirs often pay a higher rate.)
- **Filler openers Austin never says.** Verified against 3 client-call
  transcripts (2026-08-04): he uses **so / but / and then / because / I think /
  let me / I mean**. He has ZERO instances of "here's the thing," "I want to be
  clear," "and honestly," "to be honest," "the truth is," "at the end of the
  day," "make no mistake." If a sentence opens with one of those, it was
  written by an AI, not spoken by Austin. Cut it and start with the fact.
- **Announcing importance instead of being important** (Austin, 2026-08-05:
  "stating thoughts or over-narrating instead of just saying it"). Any sentence
  whose job is to tell the viewer that the NEXT sentence matters:
  "I want you to sit with this," "I want to stress," "What I want you to notice
  is," "here's the part I want you to internalize," "I want to be clear,"
  "pay attention to," "this is important because," and in walkthroughs
  "Land it:" / "Land the line:" / "Worth saying:" / "Say it out loud."
  If the point is good it lands on its own; if it needs an usher, it's weak.
  Cut the frame, keep the fact. (Swept 2026-08-05: 55 instances removed.)
  **"Let me show you…" splits on its object** (Austin, 2026-08-05). With a
  CONCRETE object it's a real signpost and it's his: "Let me show you what that
  costs," "…what I mean with our couple," "…why the two simple options both
  fail." With an ABSTRACT-IMPORTANCE object it's the same announce frame in
  disguise and it goes: "Let me show you how much one input matters," "…why that
  matters." Cut the frame and open the example instead.
  NOT banned: "Notice that…" used sparingly, and first-person disclosure that
  carries real information ("I want to be straight about these because I'm in
  this system").

- **Textbook example openers.** Austin opens an example with **"Let's walk
  through an example," "Let's say that we have a couple…," "Let's run the
  couple," "Say the couple retires at 60"** — verified in his own 2.2 dictation.
  He does NOT write **"Take someone who's 45…," "Take a couple in Texas,"
  "Consider a household…," "Imagine…," "Picture two retirees."** Those are
  written-essay constructions. Convert to the "Let's say we have…" form.
  Metaphor framings ("Picture your income as a road") get replaced with the
  actual structure, not a different picture verb.
- **"X beats Y" verdict aphorisms** (Austin, 2026-08-05: *"Rough and honest beats
  precise and late. I don't talk like this."*). The compressed maxim — two
  balanced phrases joined by beats / wins over / trumps / is better than. It
  reads as a slogan someone would put on a slide. Say the instruction instead:
  "Build the plan this week with numbers that are approximately right, then
  refine them as you go." Watch for the follow-on sentence too — when this
  pattern appears it usually restates itself once more in the same shape, and
  both copies have to go. (Swept 2026-08-05: 7 instances, incl. one that had
  been sitting under the heading "The rule the whole course runs on.")
  NOT banned: "beats" doing literal comparative work in a financial claim
  ("paying off a 20% card beats any investment you could pick with confidence"),
  or "beats" as production jargon for moments in a script.
- **Reassurance couplets** ("that isn't a character flaw, it's information").
- Abstract nouns doing the work ("the drag costs the plan"). Austin says who
  does what: "that money just sits there losing to inflation."

## Order independence (Austin, 2026-08-04)

Lessons get removed, updated, and reordered. Scripts must survive that:
- NEVER "in the next lesson" / "in the last lesson" / "as we just covered" —
  no positional references, no teasers. A lesson ends on its homework and the
  walkthrough hand-off, then stops.
- **Grep for the bare form too**, not just "in the next lesson": "The next
  lesson covers…", "That's where the next lesson starts", "(next lesson)",
  "the ceiling you set last lesson". A 2026-08-05 sweep found 6 of these in
  scripts and lesson text that an "in the next lesson" search had missed.
- Referring to another lesson BY TOPIC ("the surplus lesson," "the tax
  module") is allowed when genuinely needed, and kept rare.

## Teach-lesson closings + walkthrough hand-off (Austin, 2026-08-04)

Teach scripts may MENTION the app while teaching, but never walk clicks — the
clicking lives in the walkthrough video. Every teach lesson that has an app
component ends with an explicit hand-off, as the last homework item:

  "...and then watch the walkthrough below this video, where I'll show you
  exactly how to set this up in Orange Plan."

Austin assembles the course with the walkthrough video embedded below the
lesson video, so "below this video" is literal.

**Only the LAST teach lesson in a module gets the hand-off** (Austin,
2026-08-06). Most modules run 3-6 teach lessons against ONE walkthrough, so
a hand-off on lesson 1 of 5 promises a walkthrough that isn't below it.
Module-final teach lessons:

  ⚠ **The list that used to sit here was a hand-typed copy and it rotted**: it
  named a tenth module, and two lessons in it, that the renumber had already
  removed, and it put Module 3's hand-off on a lesson in another module.
  **`DICTATION-ORDER.md` now generates the authoritative list** under
  "Say-once items" — read it there, and regenerate with
  `python3 tools/build-dictation-order.py` rather than maintaining a second copy
  here. Module 0 has no walkthrough and gets none.

  **One rule the generated list encodes:** the hand-off goes on the last
  **required** teach lesson, never on an optional one. Module 2's optional
  college lesson (2.4) sits after 2.3 and before the walkthrough, so 2.3 carries
  the hand-off and words it to work whether or not the student takes 2.4.

Every other teach lesson ends on its homework and stops.

## Lesson openers (Austin, 2026-08-04)

This is a PAID course, not YouTube. No hooks, no stakes-selling, no "imagine
if" openers — students already bought in, and re-selling them wastes their
time. Every lesson opens with ONE line — the promise, short and sweet:

  "So in this lesson we're going to [do the thing]."

Then teach. The why-it-matters material (stories, failure scenarios) stays in
the lesson BODY as teaching content, never dressed as an opener. Don't recite
the outcomes checklist on camera — it renders on the lesson page already.

## Tables (hard rule — Austin, 2026-08-04)

A teleprompter cannot render a table. Scripts contain ZERO tables. Whatever a
table says, the script SPEAKS it as sentences in the flow ("for most
households, 6 months is the baseline; single income or variable pay, 12 or
more") and may reference the on-screen graphic ("the table on the screen gives
you the range"). If the table's cells matter to the edit, a compact copy may
sit BELOW the spoken paragraph fenced as "REFERENCE — do not read". Never
above, never instead of the spoken read.

## Register control — measured 2026-08-05 (do NOT "fix" this)

Austin's CONVERSATION and his DICTATED LESSON are different registers, and the
lesson is the right target for a teach script. Measured on sentence openers:

| corpus | chaining opener (so/and/but/now/then) | article/demonstrative opener |
|---|---|---|
| Austin, 3 client calls (1,648 sentences) | 39% | 6% |
| **Austin, his own 2.2 dictation (the master)** | **15%** | **27%** |
| The AI-written teach scripts (3,267 sentences) | 18% | 26% |

The scripts already sit on his dictated-lesson register. Someone comparing them
against the CONVERSATION numbers will conclude the scripts need "So" and "And"
injected at the front of hundreds of sentences — that change would move them
AWAY from how he actually delivers a lesson. It was proposed and rejected on
this evidence. Median sentence length also already matches (12 vs 13 words).

What a high article-opener rate in one script usually means is not stiffness but
**abstract nouns doing the work** ("Splitting the two is what protects your
willingness to keep showing up"). Fix those individually — Austin says who does
what ("You split the two so you'll actually keep showing up") — and the profile
follows on its own.

## Conversion rule of thumb

Take the lesson's idea, then ask: how would a financial planner explain this to
a friend across the table, on the first take, with digits on a napkin? Write
that down. If a sentence sounds quotable, rewrite it until it sounds said.

## Repetition budget (Austin, 2026-08-07)

An idea taught once lands. The same idea taught seven times reads as padding
and costs real course minutes. Two rules came out of the 2026-08-07 filler
sweep:

- **Teach a cross-cutting tool ONCE, in its own lesson.** The AI was being
  re-explained in 8 walkthroughs (853 words, ~6 minutes) with the same caveat
  worded four different ways. It now lives in 0.2, and every later beat is
  reduced to three things: which button, what it reads on THAT page, and when
  it's worth running. Facts for that lesson live in AI-FACTS.md, verified
  against the app code. If the app's AI changes, AI-FACTS.md changes first.
- **A jurisdiction disclaimer is a module-level statement, not a per-lesson
  tail.** "If you're outside the US" appeared 12 times, 7 of them a verbatim
  block. It's now said ONCE at the top of Module 5 and ONCE at the top of
  Module 8, plus a breakdown in 0.1 of which modules are US-shaped and how the
  app handles it (US dollars, US federal + state tax engine, no country
  setting).

## No scan lessons (Austin, 2026-08-07)

> "Anything that's 'make sure it's correct,' or scan, is useless and treating
> the user as too dumb and not respecting their time."

Cut 5.6 and 9.6, which were read-back laps with 2 and 3 click steps. What
survived moved into the module's real screen half: the "where this module's
work lives" reference table, and 8.5's decision ledger. Do not reintroduce a
"check your work" lesson. Every walkthrough already closes on a WRAP.

## Homework is an app action (Austin, 2026-08-07)

> "We don't want write it down. Implementation is in app except for
> inheritance pieces."

"Write it down" appeared in 17 homework blocks and had become a tic. Every
number with a field goes IN the app: spending, reserve target, target
allocation, bucket assignments, contributions, LTV thresholds, debt jobs,
cost basis lots, retirement spending, Social Security. Things with no field
(a debt ceiling, a refill rule, an "only one" list) are DECIDED and said out
loud, not written. The exceptions that stay on paper are the inheritance
pieces, where writing is the deliverable and the app must never hold it: the
access split (8.2) and the heir letter (8.3).

## Scan for SHAPES, not strings (Austin, 2026-08-08)

Three sweeps reported "clean" and Austin still opened a script and found this:

> "One reframe that makes this whole system click: the futures that fail at 80%
> confidence aren't random bad luck sprinkled evenly across time. They're almost
> always the same shape, which is a deep drawdown showing up in year 2 instead
> of year 15."

Three stacked slop moves and **zero literal matches** against the banned-phrase
list: an announce frame ("one reframe that makes this click"), a
negation-reversal ("aren't random bad luck… they're almost always"), and an
abstract noun doing the work ("the same shape"). The sweeps were grepping for
strings. The slop was a shape.

`tools/slop-scan.py` now scans for the shapes. Run it before declaring
anything clean. Every hit is a CANDIDATE, not a verdict; read each one.

## The "Here's" finding — measure, then cut to his rate

The single biggest tell in the corpus, and no string list would have caught it,
because every individual instance looked defensible.

| corpus | words | "Here's" | rate |
|---|---|---|---|
| Austin's 3 own dictations | 4,318 | **1** | 1 per 4,318 |
| The 38 AI-written scripts (before) | 51,530 | **81** | 1 per 636 |
| The same scripts (after) | 51,184 | **1** | 1 per 51,184 |

**6.8x his rate.** The fix split two ways:

- **39 were standalone signposts** that open a paragraph and add nothing: "Here's
  why this matters so much." followed by the paragraph that actually says why.
  Deleted outright; the content sentence is stronger as the opener.
- **42 carried their object**, and each got rewritten to state the thing instead
  of announcing it. "Here's why holding all three matters: X" becomes "Holding
  all three matters because X."

Same method applies to any formula: count it in his dictations, count it in the
scripts, and cut to his rate. Don't argue instance by instance — every single
one of the 81 was individually defensible, and collectively they were the tic.

**Check for the replacement tic afterward.** This has gone wrong here before
(a 39x "The first is" -> "The first one is" swap just installed a new uniform
formula). After the "Here's" pass, the candidate replacements measured: "X
matters because" 4, "The <noun> is that" 8, "There's a" 4, "Let me" 20 across
51k words. None at tic level. Verify this every time.

## Also swept 2026-08-08

- "Notice that/how": Austin uses it **0 times in 4,318 words**. The guide allows
  it sparingly, so it was thinned 7 -> 3 (1 per 17,000 words), cutting the ones
  where the sentence stood fine without the usher.
- Decorative metaphors and abstract nouns: "under the hood," "sprinkled evenly,"
  "the same shape," "a dent," "makes it click," "a mental model that changes
  everything," "where the money is." All replaced with the actual fact. Note
  that four of those were written during an earlier *anti-slop* pass.
- Announce frames in section headings count too: "WHAT THE CONFIDENCE NUMBER IS
  REALLY TELLING YOU" -> "WHAT THE CONFIDENCE NUMBER IS TELLING YOU."

## Lesson titles: outcome and topic, never marketing (Austin, 2026-08-08)

Every title says what the student will be able to DO and what the lesson
covers. No slogans, no coined jargon, no teasers. 35 of 52 were renamed:

- "Cost basis: the unlock for everything else" -> "Cost basis: what you paid,
  and how to reconstruct it"
- "Defense: tolerance first, then the two ratios" -> "Set your debt ceiling:
  debt-to-income and debt-to-assets"
- "Close the doors: single points of failure, hardening, and scams" ->
  "Single points of failure, account hardening, and scams"
- "The two emotion gates: stress-test + price context" -> "Stress-test the
  allocation you can actually hold"
- "The two rhythms and the monthly pass" -> "The five-minute monthly pass"

Framing devices that only make sense once you're inside the lesson (Defense /
Offense, emotion gates, rhythms, lanes, the unlock) belong in the BODY, where
they're taught. They don't belong in a title a student is scanning to decide
what to watch.

Coined course jargon in a title is the tell. If a student who has not taken
the course cannot tell what the lesson is about from the title, retitle it.

Filenames derive from titles (`tools/build-scripts.py` slugs them), so a
retitle renames files. Use `git mv` and re-run the generators; the protected
dictation files are keyed on lesson NUMBER, not filename, so they survive.

## Voice comparison against 2.2 — `tools/voice-compare.py` (2026-08-08)

Austin asked for every rewritten script to be measured against his own
dictation before it goes on the dictation list. `03-2` is the master. Running
it across all 40 AI-written teach scripts found two corpus-wide gaps, and
neither should be fixed by rewriting.

| metric | Austin (03-2) | AI scripts | verdict |
|---|---|---|---|
| **"going to" per 1k words** | **24.9** | **0.6 – 4.0** | 6–40x gap. THE tell. |
| **median sentence length** | **18 words** | 9 – 14 | he unpacks; drafts compress |
| chaining opener | 13% | 4 – 23% | in range |
| article opener | 22% | 13 – 33% | in range |
| "I think" per 1k | 1.4 | 0 – 1.1 | slightly low, tolerable |
| "because" per 1k | 4.3 | 0.6 – 9.8 | in range |

**Do NOT mass-inject "going to" or lengthen sentences mechanically.** That is
the substitution trap this project has already hit twice: a 39x "The first is"
-> "The first one is" swap installed a new uniform formula, and the "Here's"
sweep had to be checked afterward for exactly the same failure. A script with
"going to" stamped into it every forty words reads worse than one without.

The correct read is the opposite. These are teleprompter scripts, and all three
of Austin's dictations show he adds the future-tense scaffolding and the longer
unpacked sentences **himself, on the take**, without being prompted. The gap
closes at the microphone, not in the file. What the measurement is good for:

- Telling Austin what to lean into while recording, when a script feels clipped.
- Catching a script that drifts the OTHER way (over-chained, spelled-out
  numbers, an abstract-noun pile showing up as a high article-opener rate).
- Confirming after a rewrite that nothing new was installed at tic level.

Run it on anything rewritten:

    python3 tools/voice-compare.py scripts/09-2*

---

## The two drift flags that carry no signal (measured 2026-08-08)

⚠ **`tools/voice-compare.py` had been raising `FileNotFoundError` since the
renumber** and therefore measuring nothing. Its calibration master was hardcoded
to `scripts/03-2_size-your-cash-reserve…`, which the renumber moved to `02-2`. It
now resolves the master by content — the reserve lesson carrying `AUSTIN
DICTATION` — so a renumber cannot silently switch the voice tool off again.

**With it running, two of its eight metrics flag on EVERY teach script in the
course, including Austin's own dictated 0.1 and 1.1:**

| Metric | Master | Every other script | Verdict |
|---|---|---|---|
| `going_to` | 22.5 / 1k | 0.7 – 13.1 | **No signal.** 2.2 is unusually future-tense |
| `median_len` | 20 words | 9 – 18 | **No signal.** 2.2 has unusually long sentences |

A flag that fires on all 27 scripts is not measuring drift, it is measuring the
calibration master. **Do not "fix" a script toward those two numbers** — doing it
across the course would mean rewriting Austin's own dictation to match one lesson
of his own dictation.

**The metrics that do discriminate are `chaining`, `article` and `Here's`.**
Course-wide those run 5–24%, 12–35%, and 0.0–0.6 respectively. A script outside
those bands is worth reading; one inside them is in register.
